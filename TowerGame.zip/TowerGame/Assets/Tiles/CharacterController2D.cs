using UnityEngine;
using UnityEngine.Events;

public class CharacterController2D : MonoBehaviour
{
    [SerializeField] private float JumpForce = 400f;
    [Range(0, .3f)] [SerializeField] private float MovementSmoothing = .1f;
    [SerializeField] private bool AirControl = false;
    [SerializeField] private LayerMask IsGround;
    [SerializeField] private Transform GroundCheck;

    const float GroundedRadius = .2f;
    private bool Grounded;
    private Rigidbody2D Rigidbody2D;
    private bool FaceRignt = true;
    private Vector3 Velocity = Vector3.zero;

    [Header("Events")]
    [Space]

    public UnityEvent OnLandEvent;

    [System.Serializable]
    public class BoolEvent : UnityEvent<bool> { }

    private void Awake()
    {
        Rigidbody2D = GetComponent<Rigidbody2D>();

        if (OnLandEvent == null)
            OnLandEvent = new UnityEvent();
    }

    private void FixedUpdate()
    {
        bool wasGrounded = Grounded;
        Grounded = false;

        Collider2D[] colliders = Physics2D.OverlapCircleAll(GroundCheck.position, GroundedRadius, IsGround);
        for (int i = 0; i < colliders.Length; i++)
        {
            if (colliders[i].gameObject != gameObject)
            {
                Grounded = true;
                if (!wasGrounded)
                    OnLandEvent.Invoke();
            }
        }
    }

    public void Move(float move, bool jump)
    {
        if (Grounded || AirControl)
        {      

            Vector3 targetVelocity = new Vector2(move * 10f, Rigidbody2D.velocity.y);
            Rigidbody2D.velocity = Vector3.SmoothDamp(Rigidbody2D.velocity, targetVelocity, ref Velocity, MovementSmoothing);

            if (move > 0 && !FaceRignt)
            {
                Flip();
            }
            else if (move < 0 && FaceRignt)
            {
                Flip();
            }
        }
        if (Grounded && jump)
        {
            Grounded = false;
            Rigidbody2D.AddForce(new Vector2(0f, 2 * JumpForce));

        }
    }

    private void Flip()
    {
        FaceRignt = !FaceRignt;

        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }
}
